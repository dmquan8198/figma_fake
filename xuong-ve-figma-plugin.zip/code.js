// Xưởng Vẽ → Figma: dựng lại bản vẽ Xưởng Vẽ thành lớp Figma thật.
figma.showUI(__html__, { width: 440, height: 560, themeColors: true });

const log = (text, kind) => figma.ui.postMessage({ type: 'log', text, kind: kind || '' });

figma.ui.onmessage = async (msg) => {
  if (!msg || msg.type !== 'import') return;
  let d;
  try { d = JSON.parse(msg.data); } catch (e) {
    log('Không đọc được dữ liệu. Hãy dán đúng nội dung đã sao chép từ Xưởng Vẽ.', 'err');
    figma.ui.postMessage({ type: 'done' });
    return;
  }
  if (!d || !Array.isArray(d.pages)) {
    log('Dữ liệu này không phải của Xưởng Vẽ.', 'err');
    figma.ui.postMessage({ type: 'done' });
    return;
  }
  try { await importDoc(d, msg.opts || {}); }
  catch (e) { log('Lỗi: ' + (e && e.message ? e.message : e), 'err'); console.error(e); }
  figma.ui.postMessage({ type: 'done' });
};

/* ---------- chuyển đổi giá trị ---------- */
function hex(h) {
  h = String(h || '#000000').replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  const n = parseInt(h.slice(0, 6), 16) || 0;
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}
const rgba = (h, a) => Object.assign(hex(h), { a: a == null ? 1 : a });
const BLEND = { '': 'NORMAL', multiply: 'MULTIPLY', screen: 'SCREEN', overlay: 'OVERLAY', darken: 'DARKEN', lighten: 'LIGHTEN', 'color-dodge': 'COLOR_DODGE', 'color-burn': 'COLOR_BURN', 'hard-light': 'HARD_LIGHT', 'soft-light': 'SOFT_LIGHT', difference: 'DIFFERENCE', exclusion: 'EXCLUSION', hue: 'HUE', saturation: 'SATURATION', color: 'COLOR', luminosity: 'LUMINOSITY' };
const CONS_H = { l: 'MIN', r: 'MAX', lr: 'STRETCH', c: 'CENTER', s: 'SCALE' };
const CONS_V = { t: 'MIN', b: 'MAX', tb: 'STRETCH', c: 'CENTER', s: 'SCALE' };
const safe = (fn, alt) => { try { fn(); return true; } catch (e) { if (alt) { try { alt(); return true; } catch (e2) {} } return false; } };

function gradPaint(g, opacity) {
  const stops = g.s.map((s) => ({ position: Math.max(0, Math.min(1, s[0])), color: rgba(s[1], s[2] == null ? 1 : s[2]) }));
  if (g.t === 'radial') return { type: 'GRADIENT_RADIAL', gradientTransform: [[1, 0, 0], [0, 1, 0]], gradientStops: stops, opacity };
  const a = ((g.a || 0) - 90) * Math.PI / 180, dx = Math.cos(a) / 2, dy = Math.sin(a) / 2;
  const x1 = 0.5 - dx, y1 = 0.5 - dy, vx = dx * 2, vy = dy * 2, L2 = vx * vx + vy * vy || 1;
  return {
    type: 'GRADIENT_LINEAR',
    gradientTransform: [[vx / L2, vy / L2, -(x1 * vx + y1 * vy) / L2], [-vy / L2, vx / L2, (vy * x1 - vx * y1) / L2 + 0.5]],
    gradientStops: stops, opacity,
  };
}
function fillPaints(o) {
  const op = o.fo == null ? 1 : o.fo;
  if (o.grad && o.grad.s && o.grad.s.length) return [gradPaint(o.grad, op)];
  if (o.fill) return [{ type: 'SOLID', color: hex(o.fill), opacity: op }];
  return [];
}
function effectsOf(o, withBlurType) {
  return (o.fx || []).map((f) => {
    if (f.t === 'blur') return withBlurType ? { type: 'LAYER_BLUR', blurType: 'NORMAL', radius: f.b || 0, visible: !f.off } : { type: 'LAYER_BLUR', radius: f.b || 0, visible: !f.off };
    return { type: f.t === 'inner' ? 'INNER_SHADOW' : 'DROP_SHADOW', color: rgba(f.c || '#000000', f.o == null ? 0.25 : f.o), offset: { x: f.x || 0, y: f.y || 0 }, radius: f.b || 0, spread: 0, visible: !f.off, blendMode: 'NORMAL' };
  });
}
function utf8(bytes) {
  let s = '', i = 0;
  while (i < bytes.length) {
    const c = bytes[i++];
    if (c < 128) s += String.fromCharCode(c);
    else if (c < 224) s += String.fromCharCode(((c & 31) << 6) | (bytes[i++] & 63));
    else if (c < 240) s += String.fromCharCode(((c & 15) << 12) | ((bytes[i++] & 63) << 6) | (bytes[i++] & 63));
    else s += String.fromCodePoint(((c & 7) << 18) | ((bytes[i++] & 63) << 12) | ((bytes[i++] & 63) << 6) | (bytes[i++] & 63));
  }
  return s;
}
function nameOf(o) {
  if (o.comp && o.set) return Object.keys(o.vp || {}).map((k) => k + '=' + o.vp[k]).join(', ') || 'Biến thể';
  if (o.name) return o.name;
  if (o.type === 'text') return String(o.text || 'Văn bản').split('\n')[0].slice(0, 40) || 'Văn bản';
  return { frame: 'Frame', rect: 'Rectangle', ellipse: 'Ellipse', line: 'Line', arrow: 'Arrow', polygon: 'Polygon', star: 'Star', path: 'Vector', image: 'Image', slice: 'Slice', inst: 'Instance' }[o.type] || o.type;
}
function pathData(o) {
  const sx = o.pw ? o.w / o.pw : 1, sy = o.ph ? o.h / o.ph : 1, f = (v) => Math.round(v * 100) / 100, d = [];
  (o.pc || []).forEach((c) => {
    const n = c.n; if (!n || !n.length) return;
    const X = (v) => f(v * sx), Y = (v) => f(v * sy);
    d.push('M ' + X(n[0].x) + ' ' + Y(n[0].y));
    const seg = (a, b) => (!a.ox && !a.oy && !b.ix && !b.iy) ? 'L ' + X(b.x) + ' ' + Y(b.y)
      : 'C ' + X(a.x + a.ox) + ' ' + Y(a.y + a.oy) + ' ' + X(b.x + b.ix) + ' ' + Y(b.y + b.iy) + ' ' + X(b.x) + ' ' + Y(b.y);
    for (let i = 1; i < n.length; i++) d.push(seg(n[i - 1], n[i]));
    if (c.c && n.length > 1) { d.push(seg(n[n.length - 1], n[0])); d.push('Z'); }
  });
  return d.join(' ');
}

/* ---------- font ---------- */
let avail = null;
const fontLoads = new Map();
async function loadFont(fn) {
  const k = fn.family + '|' + fn.style;
  if (!fontLoads.has(k)) fontLoads.set(k, figma.loadFontAsync(fn));
  await fontLoads.get(k);
}
async function fontFor(family, weight, italic) {
  if (!avail) {
    avail = new Map();
    (await figma.listAvailableFontsAsync()).forEach((f) => {
      if (!avail.has(f.fontName.family)) avail.set(f.fontName.family, new Set());
      avail.get(f.fontName.family).add(f.fontName.style);
    });
  }
  const w = weight >= 650 ? 700 : weight >= 550 ? 600 : weight >= 450 ? 500 : 400;
  const names = { 400: ['Regular', 'Book', 'Normal'], 500: ['Medium', 'Regular'], 600: ['Semi Bold', 'SemiBold', 'Semibold', 'Demi Bold', 'DemiBold', 'Bold', 'Medium'], 700: ['Bold', 'Semi Bold', 'SemiBold'] };
  for (const fam of [family, 'Inter', 'Roboto']) {
    const st = avail.get(fam);
    if (!st) continue;
    for (const base of names[w]) {
      const cands = italic ? (base === 'Regular' ? ['Italic', 'Regular Italic'] : [base + ' Italic', base + 'Italic']) : [base];
      for (const c of cands) if (st.has(c)) { const fn = { family: fam, style: c }; await loadFont(fn); return fn; }
    }
    if (st.has('Regular')) { const fn = { family: fam, style: 'Regular' }; await loadFont(fn); return fn; }
  }
  const fn = { family: 'Inter', style: 'Regular' };
  await loadFont(fn);
  return fn;
}
async function loadNodeFonts(n) {
  if (n.type !== 'TEXT') return;
  if (n.fontName !== figma.mixed) { await loadFont(n.fontName); return; }
  const fonts = n.getRangeAllFontNames(0, n.characters.length);
  for (const f of fonts) await loadFont(f);
}

/* ---------- dựng tài liệu ---------- */
async function importDoc(d, opts) {
  const ctx = {
    d, map: new Map(), all: new Map(), kids: new Map(), pageNode: new Map(),
    vars: {}, cols: {}, fillStyles: {}, textStyles: {}, pending: [], sets: new Map(),
    building: new Set(), count: 0, fails: 0, slotWarn: false, bindFails: 0,
  };
  const pages = d.pages;
  pages.forEach((p, pi) => (p.objs || []).forEach((o) => ctx.all.set(o.id, { o, pi })));
  pages.forEach((p) => (p.objs || []).forEach((o) => {
    const k = o.parent && ctx.all.has(o.parent) ? o.parent : '#root' + pages.indexOf(p);
    if (!ctx.kids.has(k)) ctx.kids.set(k, []);
    ctx.kids.get(k).push(o);
  }));

  log('Đang tạo biến và style…');
  await buildVars(d.vars, ctx);
  await buildStyles(d.styles || {}, ctx);

  pages.forEach((p, pi) => {
    let pg;
    if (pi === 0 && opts.here) pg = figma.currentPage;
    else { pg = figma.createPage(); pg.name = p.name || 'Trang ' + (pi + 1); }
    ctx.pageNode.set(pi, pg);
  });

  for (let pi = 0; pi < pages.length; pi++) {
    const pg = ctx.pageNode.get(pi);
    log('Đang dựng trang "' + pg.name + '"…');
    for (const o of ctx.kids.get('#root' + pi) || []) await buildNode(o, ctx, pg, { x: 0, y: 0 }, null);
  }

  log('Đang gom biến thể, thuộc tính component, ghi đè instance…');
  combineSets(ctx);
  await buildComponentProps(ctx);
  await applyInstances(ctx);

  log('Đang gắn biến, tương tác nguyên mẫu…');
  for (const [id, n] of ctx.map) {
    const e = ctx.all.get(id);
    if (e) await applyBinds(e.o, n, ctx);
  }
  await applyPrototype(ctx);

  const first = ctx.pageNode.get(0);
  if (first) {
    await figma.setCurrentPageAsync(first);
    if (first.children.length) figma.viewport.scrollAndZoomIntoView(first.children);
  }
  log('Đã nhập ' + ctx.count + ' lớp vào ' + pages.length + ' trang.' + (ctx.fails ? ' ' + ctx.fails + ' lớp không dựng được.' : ''), ctx.fails ? 'warn' : 'ok');
  if (ctx.bindFails) log(ctx.bindFails + ' liên kết biến không gắn được (Figma không cho gắn biến vào thuộc tính đó).', 'warn');
  figma.notify('Xưởng Vẽ: đã nhập ' + ctx.count + ' lớp');
}

function kidsOf(ctx, id) { return ctx.kids.get(id) || []; }
function subtreeOf(ctx, id) { const r = []; for (const c of kidsOf(ctx, id)) { r.push(c); r.push(...subtreeOf(ctx, c.id)); } return r; }
function resize(n, w, h) { safe(() => n.resize(Math.max(0.01, w), Math.max(0.01, h)), () => n.resizeWithoutConstraints(Math.max(0.01, w), Math.max(0.01, h))); }
function place(n, o, pAbs) {
  const lx = o.x - pAbs.x, ly = o.y - pAbs.y;
  if (o.rot) {
    const t = o.rot * Math.PI / 180, c = Math.cos(t), s = Math.sin(t);
    const cx = lx + o.w / 2, cy = ly + o.h / 2;
    n.relativeTransform = [[c, -s, cx - (o.w / 2) * c + (o.h / 2) * s], [s, c, cy - (o.w / 2) * s - (o.h / 2) * c]];
  } else { n.x = lx; n.y = ly; }
}
function radii(n, o) {
  if (o.rr && o.rr.length === 4) {
    safe(() => { n.topLeftRadius = o.rr[0]; n.topRightRadius = o.rr[1]; n.bottomRightRadius = o.rr[2]; n.bottomLeftRadius = o.rr[3]; });
  } else if (o.r) safe(() => { n.cornerRadius = o.r; });
}
function applyStroke(n, o, open) {
  if (!o.stroke || !(o.sw > 0)) { safe(() => { n.strokes = []; }); return; }
  n.strokes = [{ type: 'SOLID', color: hex(o.stroke), opacity: o.so == null ? 1 : o.so }];
  safe(() => { n.strokeWeight = o.sw; });
  safe(() => { n.strokeAlign = open ? 'CENTER' : ({ c: 'CENTER', i: 'INSIDE', o: 'OUTSIDE' }[o.sa] || 'CENTER'); });
  if (o.sd === 'dash') safe(() => { n.dashPattern = [o.sw * 3, o.sw * 2]; });
  else if (o.sd === 'dot') safe(() => { n.dashPattern = [0.01, o.sw * 2]; });
  safe(() => { n.strokeCap = o.sd === 'dot' ? 'ROUND' : ({ butt: 'NONE', round: 'ROUND', square: 'SQUARE' }[o.sc] || 'NONE'); });
  safe(() => { n.strokeJoin = ({ miter: 'MITER', round: 'ROUND', bevel: 'BEVEL' }[o.sj] || 'MITER'); });
}
function common(n, o) {
  n.name = nameOf(o);
  if (o.hidden) n.visible = false;
  if (o.locked) n.locked = true;
  if (o.op != null && o.op < 1) n.opacity = o.op;
  if (o.bm && 'blendMode' in n) safe(() => { n.blendMode = BLEND[o.bm] || 'NORMAL'; });
  if (o.fx && o.fx.length && 'effects' in n) safe(() => { n.effects = effectsOf(o, false); }, () => { n.effects = effectsOf(o, true); });
  if (o.mask && 'isMask' in n) safe(() => { n.isMask = true; });
  if (o.ex && o.ex.length && 'exportSettings' in n) safe(() => {
    n.exportSettings = o.ex.map((e) => e.f === 'svg' ? { format: 'SVG' } : { format: e.f === 'jpg' ? 'JPG' : 'PNG', constraint: { type: 'SCALE', value: e.s || 1 } });
  });
}
async function finish(n, o, ctx, parentObj) {
  ctx.map.set(o.id, n);
  ctx.count++;
  if (parentObj && parentObj.type === 'frame' && !parentObj.lay && !parentObj.sec && 'constraints' in n) {
    safe(() => { n.constraints = { horizontal: CONS_H[o.cx] || 'MIN', vertical: CONS_V[o.cy] || 'MIN' }; });
  }
  if (o.fsid && ctx.fillStyles[o.fsid]) {
    const id = ctx.fillStyles[o.fsid].id;
    safe(() => {}, null);
    try { if (n.setFillStyleIdAsync) await n.setFillStyleIdAsync(id); else n.fillStyleId = id; } catch (e) {}
  }
  if (o.tsid && ctx.textStyles[o.tsid] && n.type === 'TEXT') {
    const id = ctx.textStyles[o.tsid].id;
    try { if (n.setTextStyleIdAsync) await n.setTextStyleIdAsync(id); else n.textStyleId = id; } catch (e) {}
  }
}

async function buildNode(o, ctx, parentNode, pAbs, parentObj) {
  try {
    switch (o.type) {
      case 'frame': return await buildFrame(o, ctx, parentNode, pAbs, parentObj);
      case 'inst': return await buildInst(o, ctx, parentNode, pAbs, parentObj);
      case 'text': return await buildText(o, ctx, parentNode, pAbs, parentObj);
      case 'image': return await buildImage(o, ctx, parentNode, pAbs, parentObj);
      default: return await buildShape(o, ctx, parentNode, pAbs, parentObj);
    }
  } catch (e) {
    ctx.fails++;
    if (ctx.fails <= 5) log('Bỏ qua "' + nameOf(o) + '": ' + (e && e.message ? e.message : e), 'warn');
    return null;
  }
}

async function buildFrame(o, ctx, parentNode, pAbs, parentObj) {
  let n = ctx.map.get(o.id);
  if (n) {
    // component đã được dựng sớm (vì có instance cần), giờ đưa về đúng chỗ
    parentNode.appendChild(n);
    if (n.parent && n.parent.type !== 'COMPONENT_SET') place(n, o, pAbs);
    return n;
  }
  if (o.sec && (parentNode.type === 'PAGE' || parentNode.type === 'SECTION')) {
    n = figma.createSection();
    parentNode.appendChild(n);
    safe(() => n.resizeWithoutConstraints(Math.max(1, o.w), Math.max(1, o.h)));
    safe(() => { n.fills = fillPaints(o); });
    n.name = nameOf(o);
    if (o.hidden) n.visible = false;
    place(n, o, pAbs);
    await finish(n, o, ctx, parentObj);
    for (const c of kidsOf(ctx, o.id)) await buildNode(c, ctx, n, { x: o.x, y: o.y }, o);
    return n;
  }
  n = o.comp ? figma.createComponent() : figma.createFrame();
  ctx.map.set(o.id, n);
  ctx.building.add(o.id);
  parentNode.appendChild(n);
  resize(n, o.w, o.h);
  n.fills = fillPaints(o);
  applyStroke(n, o, false);
  radii(n, o);
  safe(() => { n.clipsContent = o.clip !== false; });
  common(n, o);
  place(n, o, pAbs);
  await finish(n, o, ctx, parentObj);
  for (const c of kidsOf(ctx, o.id)) await buildNode(c, ctx, n, { x: o.x, y: o.y }, o);
  if (o.lay) applyLayout(n, o, ctx);
  if (o.grids && o.grids.length) {
    safe(() => {
      n.layoutGrids = o.grids.map((g) => g.t === 'grid'
        ? { pattern: 'GRID', sectionSize: Math.max(1, g.s), visible: true, color: rgba(g.c, g.o) }
        : { pattern: g.t === 'cols' ? 'COLUMNS' : 'ROWS', alignment: 'STRETCH', gutterSize: g.g || 0, count: Math.max(1, g.n | 0), offset: g.m || 0, visible: true, color: rgba(g.c, g.o) });
    });
  }
  if (o.comp && o.set) {
    if (!ctx.sets.has(o.set)) ctx.sets.set(o.set, { name: o.setName || 'Component', members: [] });
    ctx.sets.get(o.set).members.push(o);
  }
  ctx.building.delete(o.id);
  return n;
}
function applyLayout(n, o, ctx) {
  const L = o.lay;
  n.layoutMode = L.dir === 'v' ? 'VERTICAL' : 'HORIZONTAL';
  n.itemSpacing = L.gap || 0;
  const ph = L.px != null ? L.px : (L.pad || 0), pv = L.py != null ? L.py : (L.pad || 0);
  n.paddingLeft = ph; n.paddingRight = ph; n.paddingTop = pv; n.paddingBottom = pv;
  n.primaryAxisAlignItems = L.hug ? 'MIN' : ({ start: 'MIN', center: 'CENTER', end: 'MAX', between: 'SPACE_BETWEEN' }[L.mj || 'start'] || 'MIN');
  n.counterAxisAlignItems = { start: 'MIN', center: 'CENTER', end: 'MAX' }[L.alg || 'start'] || 'MIN';
  if (L.hug) { n.primaryAxisSizingMode = 'AUTO'; n.counterAxisSizingMode = 'AUTO'; }
  else {
    n.primaryAxisSizingMode = 'FIXED'; n.counterAxisSizingMode = 'FIXED';
    if (L.wrap && L.dir === 'h') safe(() => { n.layoutWrap = 'WRAP'; n.counterAxisSizingMode = 'AUTO'; });
    resize(n, o.w, o.h);
  }
  for (const c of kidsOf(ctx, o.id)) {
    const cn = ctx.map.get(c.id);
    if (!cn || cn.parent !== n) continue;
    if (c.abs) { safe(() => { cn.layoutPositioning = 'ABSOLUTE'; place(cn, c, { x: o.x, y: o.y }); }); continue; }
    if (c.lf === 'fill') safe(() => { cn.layoutAlign = 'STRETCH'; });
    if (c.lg && !L.hug) safe(() => { cn.layoutGrow = 1; });
  }
}

async function buildShape(o, ctx, parentNode, pAbs, parentObj) {
  let n;
  const open = o.type === 'line' || o.type === 'arrow' || (o.type === 'path' && (o.pc || []).some((c) => !c.c));
  if (o.type === 'rect') { n = figma.createRectangle(); resize(n, o.w, o.h); radii(n, o); }
  else if (o.type === 'ellipse') { n = figma.createEllipse(); resize(n, o.w, o.h); }
  else if (o.type === 'polygon') { n = figma.createPolygon(); resize(n, o.w, o.h); n.pointCount = Math.max(3, o.n | 0); }
  else if (o.type === 'star') { n = figma.createStar(); resize(n, o.w, o.h); n.pointCount = Math.max(3, o.n | 0); safe(() => { n.innerRadius = o.ir; }); }
  else if (o.type === 'slice') { n = figma.createSlice(); resize(n, o.w, o.h); }
  else if (o.type === 'line' || o.type === 'arrow') {
    n = figma.createVector();
    const e = o.flip ? [[0, o.h], [o.w, 0]] : [[0, 0], [o.w, o.h]];
    const cap = (k) => ({ arrow: 'ARROW_LINES', dot: 'CIRCLE_FILLED' }[k] || 'NONE');
    const net = { vertices: [{ x: e[0][0], y: e[0][1], strokeCap: cap(o.ss) }, { x: e[1][0], y: e[1][1], strokeCap: cap(o.se) }], segments: [{ start: 0, end: 1 }], regions: [] };
    if (n.setVectorNetworkAsync) await n.setVectorNetworkAsync(net); else n.vectorNetwork = net;
  } else if (o.type === 'path') {
    n = figma.createVector();
    n.vectorPaths = [{ windingRule: open ? 'NONE' : 'EVENODD', data: pathData(o) || 'M 0 0' }];
  } else throw new Error('loại lớp lạ: ' + o.type);
  parentNode.appendChild(n);
  if (o.type !== 'slice') {
    n.fills = (o.type === 'line' || o.type === 'arrow') ? [] : fillPaints(o);
    applyStroke(n, o, open);
  }
  common(n, o);
  place(n, o, pAbs);
  await finish(n, o, ctx, parentObj);
  return n;
}

async function buildText(o, ctx, parentNode, pAbs, parentObj) {
  const n = figma.createText();
  parentNode.appendChild(n);
  const fn = await fontFor(o.ff || 'Inter', o.fw || 400, !!o.it);
  n.fontName = fn;
  n.characters = String(o.text == null ? '' : o.text);
  n.fontSize = Math.max(1, o.fs || 16);
  n.lineHeight = { value: (o.lh || 1.3) * 100, unit: 'PERCENT' };
  if (o.ls) n.letterSpacing = { value: o.ls, unit: 'PIXELS' };
  n.textAlignHorizontal = { left: 'LEFT', center: 'CENTER', right: 'RIGHT', justify: 'JUSTIFIED' }[o.ta] || 'LEFT';
  n.textAlignVertical = { top: 'TOP', center: 'CENTER', bottom: 'BOTTOM' }[o.va] || 'TOP';
  if (o.td) n.textDecoration = o.td === 'underline' ? 'UNDERLINE' : 'STRIKETHROUGH';
  if (o.tc) n.textCase = { upper: 'UPPER', lower: 'LOWER', title: 'TITLE' }[o.tc] || 'ORIGINAL';
  n.fills = fillPaints(o);
  if (o.rt && o.rt.length) {
    let pos = 0;
    for (const r of o.rt) {
      const len = String(r.t || '').length;
      if (len) {
        const a = pos, b = pos + len;
        if (r.b || r.i) n.setRangeFontName(a, b, await fontFor(o.ff || 'Inter', r.b ? Math.max(o.fw || 400, 700) : (o.fw || 400), !!(o.it || r.i)));
        if (r.u || r.s) n.setRangeTextDecoration(a, b, r.u ? 'UNDERLINE' : 'STRIKETHROUGH');
        if (r.c) n.setRangeFills(a, b, [{ type: 'SOLID', color: hex(r.c) }]);
      }
      pos += len;
    }
  }
  if (o.tm === 'auto') n.textAutoResize = 'WIDTH_AND_HEIGHT';
  else if (o.tm === 'height') { n.resize(Math.max(1, o.w), Math.max(1, o.h)); n.textAutoResize = 'HEIGHT'; }
  else { n.textAutoResize = 'NONE'; n.resize(Math.max(1, o.w), Math.max(1, o.h)); }
  common(n, o);
  place(n, Object.assign({}, o, { w: n.width, h: n.height, x: o.tm === 'auto' && o.ta === 'right' ? o.x + o.w - n.width : o.tm === 'auto' && o.ta === 'center' ? o.x + (o.w - n.width) / 2 : o.x }), pAbs);
  await finish(n, o, ctx, parentObj);
  return n;
}

async function buildImage(o, ctx, parentNode, pAbs, parentObj) {
  const url = ((ctx.d.images || {})[o.src]) || '';
  let n;
  if (/^data:image\/svg/.test(url)) {
    const body = url.slice(url.indexOf(',') + 1);
    const svg = /;base64,/.test(url.slice(0, url.indexOf(',') + 1)) ? utf8(figma.base64Decode(body)) : decodeURIComponent(body);
    n = figma.createNodeFromSvg(svg);
    parentNode.appendChild(n);
    resize(n, o.w, o.h);
  } else {
    n = figma.createRectangle();
    parentNode.appendChild(n);
    resize(n, o.w, o.h);
    radii(n, o);
    if (/^data:image\//.test(url)) {
      const img = figma.createImage(figma.base64Decode(url.slice(url.indexOf(',') + 1)));
      n.fills = [{ type: 'IMAGE', imageHash: img.hash, scaleMode: o.fit === 'fit' ? 'FIT' : 'FILL' }];
    } else n.fills = [{ type: 'SOLID', color: hex('#C9C9D1') }];
    applyStroke(n, o, false);
  }
  common(n, o);
  place(n, o, pAbs);
  await finish(n, o, ctx, parentObj);
  return n;
}

/* component gốc có thể nằm ở trang khác hoặc phía sau: dựng sớm khi instance cần */
async function ensureMaster(id, ctx) {
  const ex = ctx.map.get(id);
  if (ex) return ex;
  const e = ctx.all.get(id);
  if (!e || ctx.building.has(id)) return null;
  const pg = ctx.pageNode.get(e.pi);
  const parentE = e.o.parent && ctx.all.get(e.o.parent);
  if (parentE && ctx.map.get(parentE.o.id)) {
    return await buildFrame(e.o, ctx, ctx.map.get(parentE.o.id), { x: parentE.o.x, y: parentE.o.y }, parentE.o);
  }
  return await buildFrame(e.o, ctx, pg, { x: 0, y: 0 }, null);
}

async function buildInst(o, ctx, parentNode, pAbs, parentObj) {
  const m = await ensureMaster(o.ref, ctx);
  let n;
  if (!m || m.type !== 'COMPONENT') {
    n = figma.createRectangle();
    parentNode.appendChild(n);
    resize(n, o.w, o.h);
    n.fills = [{ type: 'SOLID', color: hex('#FFE3E3') }];
    n.name = nameOf(o) + ' (thiếu component gốc)';
  } else {
    n = m.createInstance();
    parentNode.appendChild(n);
    resize(n, o.w, o.h);
    common(n, o);
    if (!o.name) n.name = m.parent && m.parent.type === 'COMPONENT_SET' ? (m.parent.name || m.name) : m.name;
    ctx.pending.push({ n, o });
  }
  place(n, o, pAbs);
  await finish(n, o, ctx, parentObj);
  // nội dung khe (slot) đặt ngay phía trên instance
  const slotKids = kidsOf(ctx, o.id);
  if (slotKids.length) {
    if (!ctx.slotWarn) { ctx.slotWarn = true; log('Nội dung khe (slot) được đặt chồng lên instance, vì plugin không ghi được vào bên trong instance.', 'warn'); }
    for (const c of slotKids) await buildNode(c, ctx, parentNode, pAbs, parentObj);
  }
  return n;
}

function combineSets(ctx) {
  for (const [sid, s] of ctx.sets) {
    const nodes = s.members.map((m) => ctx.map.get(m.id)).filter((n) => n && n.type === 'COMPONENT');
    if (nodes.length < 1) continue;
    try {
      const parent = nodes[0].parent || figma.currentPage;
      const set = figma.combineAsVariants(nodes, parent);
      set.name = s.name;
      s.node = set;
    } catch (e) { log('Không gom được bộ biến thể "' + s.name + '": ' + e.message, 'warn'); }
  }
}
const CP_TYPE = { bool: 'BOOLEAN', text: 'TEXT', swap: 'INSTANCE_SWAP', slot: 'SLOT' };
async function buildComponentProps(ctx) {
  ctx.propKey = {};
  for (const [id, e] of ctx.all) {
    const o = e.o;
    if (!(o.type === 'frame' && o.comp && o.cprops && o.cprops.length)) continue;
    const node = ctx.map.get(id);
    if (!node) continue;
    const set = o.set && ctx.sets.get(o.set) && ctx.sets.get(o.set).node;
    const target = set || node;
    for (const p of o.cprops) {
      const key = target.id + '|' + p.id;
      if (ctx.propKey[key] !== undefined) continue;
      try {
        let def = p.def;
        if (p.type === 'bool') def = !!def;
        else if (p.type === 'text') def = String(def == null ? '' : def);
        else if (p.type === 'swap') { const mn = await ensureMaster(p.def, ctx); if (!mn) { ctx.propKey[key] = null; continue; } def = mn.id; }
        else if (p.type === 'slot') { ctx.propKey[key] = target.addComponentProperty(p.name, 'SLOT', undefined); continue; }
        ctx.propKey[key] = target.addComponentProperty(p.name, CP_TYPE[p.type], def);
      } catch (err) {
        ctx.propKey[key] = null;
        if (p.type === 'slot') log('Figma chưa cho plugin tạo thuộc tính khe (slot) "' + p.name + '", khung khe được giữ như khung thường.', 'warn');
        else log('Không tạo được thuộc tính "' + p.name + '": ' + err.message, 'warn');
      }
    }
    // gắn lớp con vào thuộc tính
    for (const [cid, ce] of ctx.all) {
      const c = ce.o;
      if (!c.cp) continue;
      let q = c.parent, inside = false, guard = 0;
      while (q && guard++ < 60) { if (q === id) { inside = true; break; } const pe = ctx.all.get(q); q = pe ? pe.o.parent : null; }
      if (!inside) continue;
      const cn = ctx.map.get(cid);
      if (!cn) continue;
      const refs = {};
      const k = (pid) => ctx.propKey[target.id + '|' + pid];
      if (c.cp.vis && k(c.cp.vis)) refs.visible = k(c.cp.vis);
      if (c.cp.text && k(c.cp.text) && cn.type === 'TEXT') refs.characters = k(c.cp.text);
      if (c.cp.swap && k(c.cp.swap) && cn.type === 'INSTANCE') refs.mainComponent = k(c.cp.swap);
      if (Object.keys(refs).length) safe(() => { cn.componentPropertyReferences = Object.assign({}, cn.componentPropertyReferences || {}, refs); });
    }
  }
}
async function applyInstances(ctx) {
  for (const { n, o } of ctx.pending) {
    const me = ctx.all.get(o.ref);
    const m = me && me.o;
    if (!m) continue;
    const mn = ctx.map.get(m.id);
    const set = m.set && ctx.sets.get(m.set) && ctx.sets.get(m.set).node;
    const target = set || mn;
    // thuộc tính component
    if (o.props && target) {
      const props = {};
      for (const pid of Object.keys(o.props)) {
        const p = (m.cprops || []).find((x) => x.id === pid);
        const key = ctx.propKey && ctx.propKey[target.id + '|' + pid];
        if (!p || !key || p.type === 'slot') continue;
        let v = o.props[pid];
        if (p.type === 'swap') { const sn = await ensureMaster(v, ctx); if (!sn) continue; v = sn.id; }
        if (p.type === 'bool') v = !!v;
        if (p.type === 'text') v = String(v);
        props[key] = v;
      }
      if (Object.keys(props).length) {
        try {
          for (const t of n.findAll((x) => x.type === 'TEXT')) await loadNodeFonts(t);
          n.setProperties(props);
        } catch (e) { log('Không đặt được thuộc tính cho "' + nameOf(o) + '": ' + e.message, 'warn'); }
      }
    }
    // khe có nội dung riêng: ẩn nội dung mặc định trong instance (nội dung riêng đã đặt chồng lên trên)
    const own = new Set(kidsOf(ctx, o.id).map((c) => c.slot).filter(Boolean));
    if (own.size && mn) {
      for (const c of subtreeOf(ctx, m.id)) {
        if (!c.cp || !own.has(c.cp.slot)) continue;
        for (const k of kidsOf(ctx, c.id)) {
          const kn = ctx.map.get(k.id);
          const t = kn && n.findOne((x) => x.id.endsWith(';' + kn.id));
          if (t) safe(() => { t.visible = false; });
        }
      }
    }
    if (o.ov && mn) await applyOv(ctx, n, m, o.ov, 0);
  }
}
/* ghi đè: khoá giống Xưởng Vẽ (tên lớp, trùng tên thêm #2…), ưu tiên id lớp; đi tiếp vào bản sao lồng */
async function applyOv(ctx, n, m, ov, depth) {
  if (!m || depth > 4) return;
  const keyed = {}, seen = {};
  for (const c of subtreeOf(ctx, m.id)) {
    const base = c.name || c.type;
    seen[base] = (seen[base] || 0) + 1;
    keyed[base + (seen[base] > 1 ? '#' + seen[base] : '')] = c;
    keyed[c.id] = c;
  }
  for (const key of Object.keys(ov)) {
    const v = ov[key], c = (v && v.cid && keyed[v.cid]) || keyed[key], cn = c && ctx.map.get(c.id);
    if (!cn || !v) continue;
    const t = n.findOne((x) => x.id.endsWith(';' + cn.id));
    if (!t) continue;
    try {
      if (t.type === 'TEXT') await loadNodeFonts(t);
      if (v.text != null && t.type === 'TEXT') t.characters = String(v.text);
      if (v.fill) t.fills = [{ type: 'SOLID', color: hex(v.fill) }];
      if (v.hidden != null) t.visible = !v.hidden;
    } catch (e) {}
    if (c.type === 'inst' && t.type === 'INSTANCE') {
      const me = ctx.all.get(c.ref), m2 = me && me.o;
      if (v.props && m2) {
        const set = m2.set && ctx.sets.get(m2.set) && ctx.sets.get(m2.set).node;
        const target = set || ctx.map.get(m2.id);
        const props = {};
        for (const pid of Object.keys(v.props)) {
          const p = (m2.cprops || []).find((x) => x.id === pid);
          const k = target && ctx.propKey && ctx.propKey[target.id + '|' + pid];
          if (!p || !k || (p.type !== 'bool' && p.type !== 'text')) continue;
          props[k] = p.type === 'bool' ? !!v.props[pid] : String(v.props[pid]);
        }
        if (Object.keys(props).length) {
          try { for (const x of t.findAll((y) => y.type === 'TEXT')) await loadNodeFonts(x); t.setProperties(props); } catch (e) {}
        }
      }
      if (v.ov) await applyOv(ctx, t, m2, v.ov, depth + 1);
    }
  }
}

/* ---------- biến, style, nguyên mẫu ---------- */
async function buildVars(vd, ctx) {
  if (!vd || !vd.cols || !vd.cols.length) return;
  if (!figma.variables) { log('Phiên bản Figma này chưa hỗ trợ biến, bỏ qua phần biến.', 'warn'); return; }
  const TYPE = { color: 'COLOR', number: 'FLOAT', string: 'STRING', boolean: 'BOOLEAN' };
  for (const c of vd.cols) {
    const fc = figma.variables.createVariableCollection(c.name);
    const mm = {};
    mm[c.modes[0].id] = fc.modes[0].modeId;
    safe(() => fc.renameMode(fc.modes[0].modeId, c.modes[0].name));
    for (const m of c.modes.slice(1)) {
      try { mm[m.id] = fc.addMode(m.name); }
      catch (e) { log('Gói Figma hiện tại không cho thêm chế độ "' + m.name + '" trong "' + c.name + '". Giá trị của chế độ này được bỏ qua.', 'warn'); }
    }
    ctx.cols[c.id] = { fc, mm, c };
    for (const v of c.vars) {
      let fv;
      try { fv = figma.variables.createVariable(v.name, fc, TYPE[v.type]); }
      catch (e) { fv = figma.variables.createVariable(v.name, fc.id, TYPE[v.type]); }
      ctx.vars[v.id] = fv;
    }
  }
  for (const c of vd.cols) {
    const mm = ctx.cols[c.id].mm;
    for (const v of c.vars) {
      const fv = ctx.vars[v.id];
      for (const mid of Object.keys(mm)) {
        let val = v.vals[mid];
        if (val === undefined) val = v.vals[c.modes[0].id];
        let fval;
        if (val && typeof val === 'object' && val.alias) {
          const t = ctx.vars[val.alias];
          if (!t) continue;
          fval = figma.variables.createVariableAlias(t);
        } else fval = v.type === 'color' ? rgba(val, 1) : v.type === 'number' ? (Number(val) || 0) : v.type === 'boolean' ? !!val : String(val);
        safe(() => fv.setValueForMode(mm[mid], fval));
      }
    }
  }
}
async function buildStyles(st, ctx) {
  for (const id of Object.keys(st.fill || {})) {
    const s = st.fill[id];
    try {
      const ps = figma.createPaintStyle();
      ps.name = s.name;
      ps.paints = s.grad && s.grad.s ? [gradPaint(s.grad, 1)] : [{ type: 'SOLID', color: hex(s.color || '#000000') }];
      ctx.fillStyles[id] = ps;
    } catch (e) {}
  }
  for (const id of Object.keys(st.text || {})) {
    const s = st.text[id];
    try {
      const ts = figma.createTextStyle();
      ts.name = s.name;
      ts.fontName = await fontFor(s.ff || 'Inter', s.fw || 400, !!s.it);
      ts.fontSize = s.fs || 16;
      ts.lineHeight = { value: (s.lh || 1.3) * 100, unit: 'PERCENT' };
      if (s.ls) ts.letterSpacing = { value: s.ls, unit: 'PIXELS' };
      if (s.td) ts.textDecoration = s.td === 'underline' ? 'UNDERLINE' : 'STRIKETHROUGH';
      if (s.tc) ts.textCase = { upper: 'UPPER', lower: 'LOWER', title: 'TITLE' }[s.tc] || 'ORIGINAL';
      ctx.textStyles[id] = ts;
    } catch (e) {}
  }
}
async function applyBinds(o, n, ctx) {
  const b = o.bind;
  if (b && figma.variables) {
    for (const prop of Object.keys(b)) {
      const v = ctx.vars[b[prop]];
      if (!v) continue;
      try {
        if (prop === 'fill' || prop === 'stroke') {
          const key = prop === 'fill' ? 'fills' : 'strokes';
          const ps = n[key];
          if (Array.isArray(ps) && ps.length && ps[0].type === 'SOLID') {
            if (n.type === 'TEXT') await loadNodeFonts(n);
            n[key] = [figma.variables.setBoundVariableForPaint(ps[0], 'color', v)].concat(ps.slice(1));
          }
        } else if (prop === 'r') ['topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'].forEach((f) => n.setBoundVariable(f, v));
        else if (prop === 'w') n.setBoundVariable('width', v);
        else if (prop === 'h') n.setBoundVariable('height', v);
        else if (prop === 'gap') n.setBoundVariable('itemSpacing', v);
        else if (prop === 'px') { n.setBoundVariable('paddingLeft', v); n.setBoundVariable('paddingRight', v); }
        else if (prop === 'py') { n.setBoundVariable('paddingTop', v); n.setBoundVariable('paddingBottom', v); }
        else if (prop === 'sw') n.setBoundVariable('strokeWeight', v);
        else if (prop === 'text' && n.type === 'TEXT') { await loadNodeFonts(n); n.setBoundVariable('characters', v); }
        else if (prop === 'visible') n.setBoundVariable('visible', v);
        else if (prop === 'fs' && n.type === 'TEXT') { await loadNodeFonts(n); n.setRangeBoundVariable(0, n.characters.length, 'fontSize', v); }
        // Độ mờ, góc xoay, điểm gradient: Figma dùng thang khác hoặc chưa cho gắn, giữ giá trị đã tính.
      } catch (e) { ctx.bindFails++; }
    }
  }
  if (o.vm) {
    for (const cid of Object.keys(o.vm)) {
      const C = ctx.cols[cid];
      if (!C || !C.mm[o.vm[cid]]) continue;
      safe(() => n.setExplicitVariableModeForCollection(C.fc, C.mm[o.vm[cid]]), () => n.setExplicitVariableModeForCollection(C.fc.id, C.mm[o.vm[cid]]));
    }
  }
}
async function applyPrototype(ctx) {
  const TR = {
    instant: null,
    dissolve: { type: 'DISSOLVE', easing: { type: 'EASE_OUT' }, duration: 0.3 },
    'slide-l': { type: 'SLIDE_IN', direction: 'LEFT', matchLayers: false, easing: { type: 'EASE_OUT' }, duration: 0.3 },
    'slide-r': { type: 'SLIDE_IN', direction: 'RIGHT', matchLayers: false, easing: { type: 'EASE_OUT' }, duration: 0.3 },
    'slide-u': { type: 'SLIDE_IN', direction: 'TOP', matchLayers: false, easing: { type: 'EASE_OUT' }, duration: 0.3 },
    'slide-d': { type: 'SLIDE_IN', direction: 'BOTTOM', matchLayers: false, easing: { type: 'EASE_OUT' }, duration: 0.3 },
  };
  for (const [id, n] of ctx.map) {
    const e = ctx.all.get(id);
    const L = e && e.o.link;
    if (!L || !L.to) continue;
    let action;
    if (L.to === 'back') action = { type: 'BACK' };
    else {
      const t = ctx.map.get(L.to);
      if (!t) continue;
      action = { type: 'NODE', destinationId: t.id, navigation: 'NAVIGATE', transition: TR[L.anim] || null, preserveScrollPosition: false };
    }
    const reactions = [{ actions: [action], trigger: { type: 'ON_CLICK' } }];
    try { if (n.setReactionsAsync) await n.setReactionsAsync(reactions); else n.reactions = reactions; }
    catch (err) { log('Không gắn được tương tác cho "' + n.name + '": ' + err.message, 'warn'); }
  }
  ctx.d.pages.forEach((p, pi) => {
    const pg = ctx.pageNode.get(pi);
    const sn = p.start && ctx.map.get(p.start);
    if (pg && sn) safe(() => { pg.flowStartingPoints = [{ nodeId: sn.id, name: 'Luồng chính' }]; });
  });
}
